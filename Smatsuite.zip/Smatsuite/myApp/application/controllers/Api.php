<?php

require APPPATH . 'libraries/REST_Controller.php';

class Api extends REST_Controller {

    function __construct()
    {
        // Construct the parent class
        parent::__construct();
        $this->load->helper('url'); 
        $this->load->database();
    }

    public function getContact_get() { 
        $id = $this->input->get('contact_id');
        if($this->input->get('data-store') == "CRM")
        {
            $curl = curl_init("https://varunhummingwave.freshsales.io/api/contacts/".$id);
            curl_setopt($curl, CURLOPT_HTTPHEADER, array(
                'Authorization: Token token=SEWw3ODfGQ47Ccll8PFbCg',
                'Content-Type: application/json',
             ));
             $result = curl_exec($curl);
             $this->response($result, REST_Controller::HTTP_OK);
        }
        else
        {
            $data = $this->db->get_where("contact",['contact_id'=>$id])->row_array(); 
            $this->response($data, REST_Controller::HTTP_OK); 
        }
    }

    public function addContact_post()
    {
        if($this->input->post('data-store') == "CRM")
        {
            $myArr = array(
                "contact" => array(
                    "first_name" => $this->input->post('firstname'),
                    "last_name" => $this->input->post('lastname'),
                    "emails" => $this->input->post('email'),
                    "mobile_number" => $this->input->post('mobile_number')
                )
                );
            
            $data = json_encode($myArr);
            $curl = curl_init("https://varunhummingwave.freshsales.io/api/contacts");
            curl_setopt($curl, CURLOPT_POST, 1);
            curl_setopt($curl, CURLOPT_POSTFIELDS, $data);
            curl_setopt($curl, CURLOPT_HTTPHEADER, array(
                'Authorization: Token token=SEWw3ODfGQ47Ccll8PFbCg',
                'Content-Type: application/json',
             ));
            $result = curl_exec($curl);
            $this->response($result, REST_Controller::HTTP_OK);
        }
        else
        {
            $this->load->model('Contact_Model');
                
            $data = array( 
                'contact_id' => $this->input->post('contact_id'), 
                'firstname' => $this->input->post('firstname'),
                'lastname' => $this->input->post('lastname'), 
                'email' => $this->input->post('email'),
                'mobile_number' => $this->input->post('mobile_number'),
            );
            $this->Contact_Model->insert($data);
            $myresp = $this->db->get("contact")->result_array();
            $this->response($myresp, REST_Controller::HTTP_OK); 
        }
    }

    public function updateContact_post()
    {
        if($this->input->post('data-store') == "CRM")
        {
            $myArr = array(
                "contact" => array(
                    "emails" => $this->input->post('email'),
                    "mobile_number" => $this->input->post('mobile_number')
                )
                );
            
            $data = json_encode($myArr);
            $curl = curl_init("https://varunhummingwave.freshsales.io/api/contacts/".$this->input->post('contact_id'));
            curl_setopt($curl, CURLOPT_RETURNTRANSFER, false);
            curl_setopt($curl, CURLOPT_CUSTOMREQUEST, "PUT");
            curl_setopt($curl, CURLOPT_POSTFIELDS, $data);
            curl_setopt($curl, CURLOPT_HTTPHEADER, array(
                'Authorization: Token token=SEWw3ODfGQ47Ccll8PFbCg',
                'Content-Type: application/json',
             ));
             $result = curl_exec($curl);
             $this->response($result, REST_Controller::HTTP_OK);
        }
        else
        {
            $this->load->model('Contact_Model');

            $data = array( 
                'email' => $this->input->post('email'),
                'mobile_number' => $this->input->post('mobile_number'),
            ); 
                
            $old_contact_id = $this->input->post('contact_id'); 
            $this->Contact_Model->update($data,$old_contact_id);
            $myresp = $this->db->get("contact")->result_array();
            $this->response($myresp, REST_Controller::HTTP_OK);
        }
    }

    public function deleteContact_post()
    {
        if($this->input->post('data-store') == "CRM")
        {
            $curl = curl_init("https://varunhummingwave.freshsales.io/api/contacts/".$this->input->post('contact_id'));
            curl_setopt($curl, CURLOPT_CUSTOMREQUEST, "DELETE");
            curl_setopt($curl, CURLOPT_HTTPHEADER, array(
                'Authorization: Token token=SEWw3ODfGQ47Ccll8PFbCg',
                'Content-Type: application/json',
             ));
             $result = curl_exec($curl);
             $this->response($result, REST_Controller::HTTP_OK);
        }
        else
        {
            $this->load->model('Contact_Model'); 
            $contact_id = $this->input->post('contact_id'); 
            $this->Contact_Model->delete($contact_id); 
            $myresp = $this->db->get("contact")->result_array();
            $this->response($myresp, REST_Controller::HTTP_OK);        }
    }
}