<?php 
   class Contact extends CI_Controller {
	
      function __construct() { 
         parent::__construct(); 
         $this->load->helper('url'); 
         $this->load->database();
      } 
  
      public function index() { 
         $query = $this->db->get("contacts"); 
         $data['records'] = $query->result(); 
         echo $data;
         $this->load->helper('url'); 
      } 
  
      public function add_student() { 
         $this->load->model('Contact_Model');
			
         $data = array( 
            'contact_id' => $this->input->get('contact_id'), 
            'firstname' => $this->input->get('firstname'),
            'lastname' => $this->input->get('lastname'), 
            'email' => $this->input->get('email'),
            'mobile_number' => $this->input->get('mobile_number'),
         ); 
			
         $this->Contact_Model->insert($data); 
   
         $query = $this->db->get("contacts"); 
         $data['records'] = $query->result(); 
      } 
  
      public function update_student(){ 
         $this->load->model('Contact_Model');
			
         $data = array( 
            'contact_id' => $this->input->get('contact_id'), 
            'firstname' => $this->input->get('firstname'),
            'lastname' => $this->input->get('lastname'), 
            'email' => $this->input->get('email'),
            'mobile_number' => $this->input->get('mobile_number'),
         ); 
			
         $old_contact_id = $this->input->get('old_contact_id'); 
         $this->Contact_Model->update($data,$old_contact_id); 
			
         $query = $this->db->get("contacts"); 
         $data['records'] = $query->result(); 
      } 
  
      public function delete_student() { 
         $this->load->model('Contact_Model'); 
         $contact_id = $this->uri->segment('3'); 
         $this->Contact_Model->delete($contact_id); 
   
         $query = $this->db->get("contacts"); 
         $data['records'] = $query->result(); 
      } 
   } 
?>