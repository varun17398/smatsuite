<?php 
   class Contact_Model extends CI_Model {
	
      function __construct() { 
         parent::__construct(); 
        $this->load->database();
         $this->load->dbforge();
      } 
   
      public function insert($data) { 
         if ($this->db->insert("contact", $data)) { 
            return true; 
         } 
      } 
   
      public function delete($contact_id) { 
         if ($this->db->delete("contact", "contact_id = ".$contact_id)) { 
            return true; 
         } 
      } 
   
      public function update($data,$old_contact_id) { 
         $this->db->set($data); 
         $this->db->where("contact_id", $old_contact_id); 
         $this->db->update("contact", $data);

      } 
   } 
?> 